import 'package:cloud_firestore/cloud_firestore.dart';

class PlaceModel {
  String? placesModelDocumentId;
  String? placesModelName; //  placesModel
  String? placesModelCityId;
  String? placeId;
  String? placesModelHeroImageUrl;
  List? placesModelImageUrls;
  List? placesModelTypes;
  String? placesModelOpeningTime;
  String? placesModelLocation;
  GeoPoint? placesModelGeopoint;
  String? placesModelDescription;
  bool? placesModelIsRecommended = false;
  num? placesModelRating;
  bool? placesModelActive;
  Timestamp? placesModelTimestamp;

  PlaceModel({
    this.placesModelDocumentId,
    this.placesModelName,
    this.placesModelCityId,
    this.placeId,
    this.placesModelHeroImageUrl,
    this.placesModelImageUrls,
    this.placesModelTypes,
    this.placesModelOpeningTime,
    this.placesModelLocation,
    this.placesModelGeopoint,
    this.placesModelDescription,
    this.placesModelIsRecommended,
    this.placesModelRating,
    this.placesModelActive,
    this.placesModelTimestamp,
  });

  factory PlaceModel.fromFirestore(DocumentSnapshot snapshot) {
    Map d = snapshot.data() as Map<dynamic, dynamic>;
    return PlaceModel(
      placesModelDocumentId: snapshot.id,
      placesModelName: d['name'],
      placesModelCityId: d['cityId'],
      placeId: d['placeId'],
      placesModelHeroImageUrl: d['heroImageUrl'],
      placesModelImageUrls: d['imageUrls'],
      placesModelTypes: d['types'],
      placesModelOpeningTime: d['openingTime'],
      placesModelLocation: d['location'],
      placesModelGeopoint: d['geopoint'],
      placesModelDescription: d['description'],
      placesModelIsRecommended: d['isRecommended'],
      placesModelRating: d['rating'],
      placesModelActive: d['active'],
      placesModelTimestamp: d['timestamp'],
    );
  }
}
