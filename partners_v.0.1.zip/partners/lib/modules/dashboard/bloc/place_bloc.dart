import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:partners/modules/dashboard/models/place_model.dart';

class PlaceBloc extends ChangeNotifier {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  List<PlaceModel> _placeData = [];
  List<PlaceModel> get palceData => _placeData;

  bool _isLoading = true;
  bool get loading => _isLoading;

  Future getPlaceData() async {
    /* 
      if(has data) return;
     */
    _placeData.clear();
    final List<DocumentSnapshot> snap = [];
    QuerySnapshot rawData = await firestore.collection('places').where('active', isEqualTo: true).get();
    snap.addAll(rawData.docs);
    _placeData = snap.map((e) => PlaceModel.fromFirestore(e)).toList();
    _isLoading = false;

    notifyListeners();
  }

  onRefresh(mounted) {
   // if (mounted) {
      _isLoading = true;
      _placeData.clear();
      getPlaceData();
      notifyListeners();
    //}
  }
}