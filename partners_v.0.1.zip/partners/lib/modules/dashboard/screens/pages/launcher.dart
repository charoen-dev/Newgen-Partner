import 'package:flutter/material.dart';
import 'package:partners/modules/dashboard/screens/pages/homes/home_page.dart';
import 'package:partners/modules/dashboard/screens/pages/places/places_create.dart';
import 'package:partners/modules/dashboard/screens/pages/settings/settings_home.dart';

class LauncherPages extends StatefulWidget {
  const LauncherPages({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return _LauncherPagesState();
  }
}

class _LauncherPagesState extends State<LauncherPages> {
  // ***** Section 0 : Setup NavigationBar ***** //

  int _selectedIndex = 0;

  final List<Widget> _pageWidget = <Widget>[
    const HomePage(),
    const PlacesCreate(),
    const PlacesCreate(),
    const AnimatedListSample(),
  ];

  final List<BottomNavigationBarItem> _menuBar = <BottomNavigationBarItem>[
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.home,
      ),
      label: 'หน้าหลัก',
    ),
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.emoji_events,
      ),
      label: 'xxxxx',
    ),
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.notifications,
      ),
      label: 'xxxxx',
    ),
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.menu,
      ),
      label: 'xxxxx',
    ),
  ];

  void _onItemTapped(int index) {
    setState(
      () {
        _selectedIndex = index;
      },
    );
  }

  // ***** Section 0 : Setup NavigationBar ***** //

  @override
  Widget build(BuildContext context) {
    // ***** Section 1 : Build ***** //

    return Scaffold(
      body: _pageWidget.elementAt(
        _selectedIndex,
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: _menuBar,
        currentIndex: _selectedIndex,
        selectedItemColor: Theme.of(context).primaryColor,
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
      ),
    );

    // ***** Section 1 : Build ***** //
  }
}
