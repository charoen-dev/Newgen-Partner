import 'package:flutter/material.dart';
import 'package:partners/modules/dashboard/screens/pages/places/places_create.dart';
import 'package:partners/modules/dashboard/screens/pages/places/places_home.dart';
import 'package:partners/modules/dashboard/screens/pages/settings/settings_home.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

List iTemsGridViewText = [
  'ที่เที่ยว',
  'ร้านอาหาร',
  'ที่พัก',
  'ช้อปปิ้ง',
  'กิจกรรม',
];

List iTemsGridViewImages = [
  'assets/logo/icon/ico_place_512.png',
  'assets/logo/icon/ico_restaurant_512.png',
  'assets/logo/icon/ico_accommodation_512.png',
  'assets/logo/icon/ico_shop_512.png',
  'assets/logo/icon/ico_activity_512.png',
];

class _HomePageState extends State<HomePage> {
  final List<Widget> _pageWidget = <Widget>[
    const PlacesHome(),
    const PlacesCreate(),
    const PlacesCreate(),
    const AnimatedListSample(),
    const AnimatedListSample(),
  ];

  final List<BottomNavigationBarItem> _bottomNavigationBarList =
      <BottomNavigationBarItem>[
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.home,
      ),
      label: 'หน้าหลัก',
    ),
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.emoji_events,
      ),
      label: 'ปปปป',
    ),
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.notifications,
      ),
      label: 'ปปปป',
    ),
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.menu,
      ),
      label: 'ปปปปiii',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    // ===== Menu List ===== //
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'NewgenVenture Partner',
          style: TextStyle(
            fontWeight: FontWeight.normal,
            fontSize: 18.0,
          ),
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.only(
              right: 20.0,
            ),
            child: CircleAvatar(
              radius: 20.0,
              backgroundImage:
                  NetworkImage('https://picsum.photos/250?image=1'),
            ),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(
            4.0,
          ),
          child: Container(
            color: Colors.grey,
            height: 1.0,
          ),
        ),
      ),
      body: GridView.count(
        crossAxisCount: 3,
        children: List.generate(
          iTemsGridViewText.length,
          (index) {
            return InkWell(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => _pageWidget[index],
                ),
              ),
              child: Column(
                children: [
                  const SizedBox(
                    height: 20.0,
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(5.5),
                          child: Image.asset(
                            iTemsGridViewImages[index].toString(),
                            height: 45.0,
                            width: 45.0,
                            fit: BoxFit.scaleDown,
                            scale: 1.0,
                            errorBuilder: (BuildContext context,
                                Object exception, StackTrace? stackTrace) {
                              return Container(
                                color: Colors.amber,
                                alignment: Alignment.center,
                                child: const Text(
                                  'Oops !',
                                  style: TextStyle(fontSize: 15.0),
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                  Text(
                    iTemsGridViewText[index],
                  ),
                  // Text(
                  //   categories[index].categoryName,
                  // )
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
