import 'dart:io';

import 'package:badges/badges.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:partners/modules/dashboard/bloc/place_bloc.dart';
import 'package:partners/modules/dashboard/screens/pages/homes/home_page.dart';
import 'package:partners/modules/dashboard/screens/pages/places/places_edit.dart';
import 'package:partners/modules/dashboard/screens/pages/settings/settings_home.dart';
import 'package:provider/provider.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;

class PlacesCreate extends StatefulWidget {
  const PlacesCreate({Key? key}) : super(key: key);

  @override
  State<PlacesCreate> createState() => _PlacesCreateState();
}

class _PlacesCreateState extends State<PlacesCreate> {
  TextEditingController controller = TextEditingController();
  @override
  void initState() {
    super.initState();
    getPlaceData();
  }

  Future getPlaceData() async {
    await context.read<PlaceBloc>().getPlaceData();
  }

  Future onRefresh() async {
    Provider.of<PlaceBloc>(context).onRefresh(mounted);
  }

  // ***** Section 0 : Setup NavigationBar ***** //

  int _selectedIndex = 0;

  final List<Widget> _pageWidget = <Widget>[
    const HomePage(),
    const PlacesCreate(),
    const PlacesCreate(),
    const AnimatedListSample(),
  ];

  final List<BottomNavigationBarItem> _menuBar = <BottomNavigationBarItem>[
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.home,
      ),
      label: 'หน้าหลัก',
    ),
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.emoji_events,
      ),
      label: 'xxxxx',
    ),
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.notifications,
      ),
      label: 'xxxxx',
    ),
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.menu,
      ),
      label: 'xxxxx',
    ),
  ];

  void _onItemTapped(int index) {
    setState(
      () {
        _selectedIndex = index;
      },
    );
  }

  // ***** Section 0 : Setup NavigationBar ***** //
  final leftEditIcon = Container(
    color: Colors.green,
    alignment: Alignment.centerLeft,
    child: const Icon(Icons.edit),
  );
  final rightDeleteIcon = Container(
    color: Colors.red,
    alignment: Alignment.centerRight,
    child: const Icon(Icons.delete),
  );

  bool isSwitchedActive = true;
  bool isSwitchedRecommended = false;
  bool _checkPickerHeroImage = false;
  final setDocId =
      FirebaseFirestore.instance.collection('cities').doc().id.toString();

  File? _photo;
  final ImagePicker _picker = ImagePicker();

  Future pickerHeroImageFromGallery() async {
    final pickedFile = await _picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 1280.0,
      maxHeight: 960.0,
      imageQuality: 80,
    );
    setState(
      () {
        if (pickedFile != null) {
          _photo = File(
            pickedFile.path,
          );
          uploadFile();
        } else {
          Fluttertoast.showToast(
            msg: 'ไม่ได้เลือกรูปภาพ',
            gravity: ToastGravity.BOTTOM,
            toastLength: Toast.LENGTH_SHORT,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0,
          );
        }
      },
    );
  }

  Future uploadFile() async {
    if (_photo == null) return;

    final imageFileName = _photo!.path;
    const imageMainFolder = 'places_images/';
    final imageSubFolder = setDocId;

    try {
      final refUploadImage = firebase_storage.FirebaseStorage.instance
          .ref(
            imageMainFolder,
          )
          .child(
            imageSubFolder,
          )
          .child(
            imageFileName,
          );

      final bucket = refUploadImage.bucket;

      debugPrint(
          'MainPart = https://firebasestorage.googleapis.com/v0/b/$bucket/o/cities_images%2F$imageSubFolder%2F${refUploadImage.name}/?alt=media');

      await refUploadImage.putFile(
        _photo!,
      );
      Fluttertoast.showToast(
        msg: 'อัพโหลดสำเร็จ',
        gravity: ToastGravity.BOTTOM,
        toastLength: Toast.LENGTH_SHORT,
        timeInSecForIosWeb: 1,
        backgroundColor: const Color(0xFFEEEEEE),
        textColor: const Color(0xFF222831),
        fontSize: 16.0,
      );
    } catch (e) {
      Fluttertoast.showToast(
        msg: 'เกิดข้อผิดพลาด',
        gravity: ToastGravity.CENTER,
        toastLength: Toast.LENGTH_SHORT,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.red,
        textColor: Colors.white,
        fontSize: 16.0,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final placeBlocPreview = context.watch<PlaceBloc>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('เพิ่มสถานที่ท่องเที่ยว'),
        centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.only(
              right: 10.0,
            ),
            child: IconButton(
              icon: const Icon(Icons.save),
              tooltip: 'บันทึก',
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const PlacesEdit(),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: 1,
        itemBuilder: (context, inputImagesNo) {
          return Padding(
            padding: const EdgeInsets.all(
              5.0,
            ),
            child: Column(
              children: [
                GridView.count(
                  shrinkWrap: true,
                  crossAxisCount: 4,
                  children: List.generate(
                    8,
                    (inputImagesNo) {
                      return Center(
                        child:
                            //****** */
                            Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Stack(
                            children: [
                              Container(
                                width: double.infinity,
                                margin: const EdgeInsets.all(
                                  1.0,
                                ),
                                child: ClipRRect(
                                  borderRadius: const BorderRadius.only(
                                    topLeft: Radius.circular(
                                      5.0,
                                    ),
                                    topRight: Radius.circular(
                                      5.0,
                                    ),
                                  ),
                                  child: Card(
                                    child: InkWell(
                                      onTap: () {
                                        print("tapped");

                                        if (inputImagesNo == 0) {
                                          _showPickerHeroImage(context);
                                          _checkPickerHeroImage = true;
                                        }
                                      },
                                      child: SizedBox(
                                        width: 100.0,
                                        height: 100.0,
                                        child: DottedBorder(
                                          color: Colors.grey,
                                          strokeWidth: 2.0,
                                          padding: const EdgeInsets.all(
                                            5.0,
                                          ),
                                          child: Stack(
                                            alignment: Alignment.center,
                                            children: [
                                              // Image.network(
                                              //   'https://picsum.photos/250?image=1',
                                              // ),
                                              const FlutterLogo(
                                                size: 148,
                                              ),
                                              Text(
                                                inputImagesNo == 0
                                                    ? 'ภาพปก'
                                                    : inputImagesNo.toString() ,//'รูปภาพ',
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),

                                  // GestureDetector(
                                  //   onTap: () {
                                  //     if (inputImagesNo == 0) {
                                  //       _showPickerHeroImage(context);
                                  //     }

                                  //   },
                                  // ),

                                  // DottedBorder(
                                  //   color: Colors.grey,
                                  //   strokeWidth: 2.0,
                                  //   padding: EdgeInsets.all(
                                  //     5.0,
                                  //   ),
                                  //   child: Stack(
                                  //     alignment: Alignment.center,
                                  //     children: [
                                  //       Image.network('https://picsum.photos/250?image=1'),
                                  //       // FlutterLogo(
                                  //       //   size: 148,
                                  //       // ),
                                  //       Text(
                                  //         inputImagesNo == 0
                                  //             ? 'ภาพปก'
                                  //             : 'รูปภาพ',
                                  //       ),
                                  //     ],
                                  //   ),
                                  // ),

                                  // Image(
                                  //   image: NetworkImage(
                                  //       'https://picsum.photos/250?image=1'),
                                  // ),
                                ),
                              ),
                              Positioned(
                                bottom: 0.0,
                                child: inputImagesNo == 0
                                    ? ClipRRect(
                                        borderRadius: const BorderRadius.all(
                                          Radius.circular(
                                            5.0,
                                          ),
                                        ),
                                        child: Container(
                                          width: 500,
                                          color: Colors.black54,
                                          padding: const EdgeInsets.all(
                                            4.0,
                                          ),
                                          child: const Text(
                                            'ภาพปก',
                                            style: TextStyle(
                                              fontSize: 10,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                      )
                                    : const ClipRRect(
                                        borderRadius: BorderRadius.all(
                                          Radius.circular(
                                            5.0,
                                          ),
                                        ),
                                      ),
                              ),
                              Positioned(
                                right: 0.0,
                                child: inputImagesNo == 7
                                    ? Badge(
                                        showBadge: false,
                                        toAnimate: true,
                                        shape: BadgeShape.square,
                                        badgeColor: Colors.red,
                                        borderRadius: const BorderRadius.all(
                                          Radius.circular(
                                            5.0,
                                          ),
                                        ),
                                        badgeContent: InkWell(
                                          onTap: () {
                                            print('Badge = $inputImagesNo');
                                          },
                                          child: const Icon(
                                            Icons.close,
                                            size: 15.0,
                                            color: Colors.white,
                                          ),
                                        ),
                                      )
                                    : Badge(
                                        toAnimate: true,
                                        shape: BadgeShape.square,
                                        badgeColor: Colors.red,
                                        borderRadius: const BorderRadius.all(
                                          Radius.circular(
                                            5.0,
                                          ),
                                        ),
                                        badgeContent: InkWell(
                                          onTap: () {
                                            print('BadgeNO = $inputImagesNo');
                                          },
                                          child: const Icon(
                                            Icons.close,
                                            size: 15.0,
                                            color: Colors.white,
                                          ),
                                        ),

                                        //--
                                      ),
                              ),
                            ],
                          ),
                        ),

                        //*** */
                      );
                    },
                  ),
                ),

                const Align(
                  alignment: Alignment.centerLeft,
                  child: Padding(
                    padding: EdgeInsets.only(left: 10.0),
                    child: Text('สูงสุด 8 ภาพ ขนาดไม่เกิน 2 MB'),
                  ),
                ),

                const SizedBox(
                  height: 20.0,
                ),

                //****

                Container(
                  padding: const EdgeInsets.only(
                      left: 5.0, top: 15.0, bottom: 10.0, right: 10.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'จังหวัด',
                              style: TextStyle(
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ],
                        ),
                      ),
                      InkWell(
                        child: const Text('น่าน'),
                        onTap: () {
                          print('f');
                          showCupertinoModalPopup<void>(
                            context: context,
                            builder: (BuildContext context) =>
                                CupertinoActionSheet(
                              title: const Text('Title'),
                              message: const Text('Message'),
                              actions: <CupertinoActionSheetAction>[
                                CupertinoActionSheetAction(
                                  child: const Text('ตกลง'),
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                      const Icon(
                        Icons.chevron_right,
                      ),
                    ],
                  ),
                ),
                // */
                Container(
                  padding: const EdgeInsets.all(5.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: const <Widget>[
                                Text('ชื่อสถานที่', textAlign: TextAlign.start),
                                Text(
                                  '*',
                                  textAlign: TextAlign.start,
                                  style: TextStyle(
                                    fontSize: 20.0,
                                    color: Colors.red,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(
                        width: 200.0,
                        child: TextField(
                          // maxLength: 100,
                          decoration: InputDecoration.collapsed(
                            hintText: '',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                // ***
                Container(
                  padding: const EdgeInsets.all(5.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'รายละเอียด',
                              style: TextStyle(
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ],
                        ),
                      ),
                      InkWell(
                        child: const Text('ตั้งค่า'),
                        onTap: () {
                          print('f');
                          showCupertinoModalPopup<void>(
                            context: context,
                            builder: (BuildContext context) =>
                                CupertinoActionSheet(
                              title: const Text('Title'),
                              message: const Text('Message'),
                              actions: <CupertinoActionSheetAction>[
                                CupertinoActionSheetAction(
                                  child: const Text('ตกลง'),
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                      const Icon(
                        Icons.chevron_right,
                      ),
                    ],
                  ),
                ),
                // ***
                Container(
                  padding:
                      const EdgeInsets.only(left: 5.0, top: 15.0, right: 10.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'ความนิยม',
                              style: TextStyle(
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ],
                        ),
                      ),
                      InkWell(
                        child: const Text('4.5'),
                        onTap: () {
                          print('f');
                          showCupertinoModalPopup<void>(
                            context: context,
                            builder: (BuildContext context) =>
                                CupertinoActionSheet(
                              title: const Text('Title'),
                              message: const Text('Message'),
                              actions: <CupertinoActionSheetAction>[
                                CupertinoActionSheetAction(
                                  child: const Text('ตกลง'),
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
                // ***
                Container(
                  padding: const EdgeInsets.only(
                      left: 5.0, top: 15.0, bottom: 10.0, right: 10.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'เวลาทำการ',
                              style: TextStyle(
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ],
                        ),
                      ),
                      InkWell(
                        child: const Text('08:00 - 20:00 น.'),
                        onTap: () {
                          print('f');
                          showCupertinoModalPopup<void>(
                            context: context,
                            builder: (BuildContext context) =>
                                CupertinoActionSheet(
                              title: const Text('Title'),
                              message: const Text('Message'),
                              actions: <CupertinoActionSheetAction>[
                                CupertinoActionSheetAction(
                                  child: const Text('ตกลง'),
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
                // ***
                Container(
                  padding:
                      const EdgeInsets.only(left: 5.0, top: 15.0, right: 10.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'ประเภทสถานที่',
                              style: TextStyle(
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ],
                        ),
                      ),
                      InkWell(
                        child: const Text('น่าน'),
                        onTap: () {
                          print('f');
                          showCupertinoModalPopup<void>(
                            context: context,
                            builder: (BuildContext context) =>
                                CupertinoActionSheet(
                              title: const Text('Title'),
                              message: const Text('Message'),
                              actions: <CupertinoActionSheetAction>[
                                CupertinoActionSheetAction(
                                  child: const Text('ตกลง'),
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
                // ***
                Container(
                  padding:
                      const EdgeInsets.only(left: 5.0, top: 15.0, right: 10.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'สถานที่ยอดนิยม',
                              style: TextStyle(
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Switch(
                        value: isSwitchedRecommended,
                        activeColor: Colors.green,
                        onChanged: (value) {
                          setState(() {
                            isSwitchedRecommended = value;
                          });
                        },
                      ),
                    ],
                  ),
                ),
                // ***
                Container(
                  padding: const EdgeInsets.only(left: 5.0, right: 10.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'แสดงผล',
                              style: TextStyle(
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Switch(
                        value: isSwitchedActive,
                        activeColor: Colors.green,
                        onChanged: (value) {
                          setState(() {
                            isSwitchedActive = value;
                          });
                        },
                      ),
                    ],
                  ),
                ),
                // **
                Container(
                  padding:
                      const EdgeInsets.only(left: 5.0, top: 15.0, right: 10.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'ที่อยู่',
                              style: TextStyle(
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ],
                        ),
                      ),
                      InkWell(
                        child: const Text('น่าน'),
                        onTap: () {
                          print('f');
                          showCupertinoModalPopup<void>(
                            context: context,
                            builder: (BuildContext context) =>
                                CupertinoActionSheet(
                              title: const Text('Title'),
                              message: const Text('Message'),
                              actions: <CupertinoActionSheetAction>[
                                CupertinoActionSheetAction(
                                  child: const Text('ตกลง'),
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                      const Icon(
                        Icons.chevron_right,
                      ),
                    ],
                  ),
                ),
                // ***
              ],
            ),
          );
        },
      ),

      // ----- Bottom Navigation Bar ----- //
      bottomNavigationBar: BottomNavigationBar(
        items: _menuBar,
        currentIndex: _selectedIndex,
        selectedItemColor: Theme.of(context).primaryColor,
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
      ),
      // ----- Bottom Navigation Bar ----- //
    );
  }

  void _showPickerHeroImage(context) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext bc) {
        return SafeArea(
          child: Wrap(
            children: <Widget>[
              ListTile(
                leading: const Icon(
                  Icons.photo_library,
                ),
                title: const Text(
                  'เลือกภาพปกจากแกลลอรี่',
                ),
                onTap: () {
                  // imgFromGallery();
                  pickerHeroImageFromGallery();
                  Navigator.of(context).pop();
                },
              ),
              ListTile(
                leading: const Icon(
                  Icons.photo_camera,
                ),
                title: const Text(
                  'เลือกภาพปกจากกล้อง',
                ),
                onTap: () {
                  // imgFromCamera();
                  // pickerHeroImageFromCamera();
                  Navigator.of(context).pop();
                },
              ),
            ],
          ),
        );
      },
    );
  }
}
