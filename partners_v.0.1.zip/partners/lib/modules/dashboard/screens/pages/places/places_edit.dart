import 'package:badges/badges.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:partners/modules/dashboard/bloc/place_bloc.dart';
import 'package:partners/modules/dashboard/screens/pages/places/places_create.dart';
import 'package:partners/modules/dashboard/screens/pages/settings/settings_home.dart';
import 'package:provider/provider.dart';

class PlacesEdit extends StatefulWidget {
  const PlacesEdit({Key? key}) : super(key: key);

  @override
  State<PlacesEdit> createState() => _PlacesEditState();
}

class _PlacesEditState extends State<PlacesEdit> {
  TextEditingController controller = TextEditingController();
  @override
  void initState() {
    super.initState();
    getPlaceData();
  }

  Future getPlaceData() async {
    await context.read<PlaceBloc>().getPlaceData();
  }

  Future onRefresh() async {
    Provider.of<PlaceBloc>(context).onRefresh(mounted);
  }

  // ***** Section 0 : Setup NavigationBar ***** //

  int _selectedIndex = 0;

  final List<Widget> _pageWidget = <Widget>[
    const PlacesEdit(),
    const PlacesCreate(),
    const PlacesCreate(),
    const AnimatedListSample(),
  ];

  final List<BottomNavigationBarItem> _menuBar = <BottomNavigationBarItem>[
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.home,
      ),
      label: 'หน้าหลัก',
    ),
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.emoji_events,
      ),
      label: 'xxxxx',
    ),
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.notifications,
      ),
      label: 'xxxxx',
    ),
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.menu,
      ),
      label: 'xxxxx',
    ),
  ];

  void _onItemTapped(int index) {
    setState(
      () {
        _selectedIndex = index;
      },
    );
  }

  // ***** Section 0 : Setup NavigationBar ***** //
  bool isSwitchedActive = true;
  bool isSwitchedRecommended = false;
  @override
  Widget build(BuildContext context) {
    final placeBlocPreview = context.watch<PlaceBloc>();

    return Scaffold(
      appBar: AppBar(
        // title: const Text('แก้ไขสถานที่ท่องเที่ยว'),
        // centerTitle: true,

        actions: [
          Padding(
            padding: const EdgeInsets.only(
              right: 10.0,
            ),
            child: IconButton(
              icon: const Icon(Icons.save),
              tooltip: 'Increase volume by 10',
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const PlacesEdit(),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: 1,
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.all(
              5.0,
            ),
            child: Column(
              children: [
                GridView.count(
                  shrinkWrap: true,
                  crossAxisCount: 4,
                  children: List.generate(
                    8,
                    (index) {
                      return Center(
                        child:
                            //****** */
                            Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Stack(
                            children: [
                              Container(
                                width: double.infinity,
                                margin: const EdgeInsets.all(
                                  1.0,
                                ),
                                child: const ClipRRect(
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(
                                      5.0,
                                    ),
                                    topRight: Radius.circular(
                                      5.0,
                                    ),
                                  ),
                                  child: Image(
                                    image: NetworkImage(
                                        'https://picsum.photos/250?image=1'),
                                  ),
                                ),
                              ),
                              Positioned(
                                bottom: 0.0,
                                child: index == 0
                                    ? ClipRRect(
                                        borderRadius: const BorderRadius.all(
                                          Radius.circular(
                                            5.0,
                                          ),
                                        ),
                                        child: Container(
                                          width: 500,
                                          color: Colors.black54,
                                          padding: const EdgeInsets.all(
                                            4.0,
                                          ),
                                          child: const Text(
                                            'ภาพปก',
                                            style: TextStyle(
                                              fontSize: 10,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                      )
                                    : const ClipRRect(
                                        borderRadius: BorderRadius.all(
                                          Radius.circular(
                                            5.0,
                                          ),
                                        ),
                                      ),
                              ),
                              Positioned(
                                right: 0.0,
                                child: Badge(
                                  toAnimate: true,
                                  shape: BadgeShape.square,
                                  badgeColor: Colors.red,
                                  borderRadius: const BorderRadius.all(
                                    Radius.circular(
                                      5.0,
                                    ),
                                  ),
                                  badgeContent: InkWell(
                                    onTap: () {
                                      print('f');

                                      print(index);
                                    },
                                    child: const Icon(
                                      Icons.close,
                                      size: 15.0,
                                      color: Colors.white,
                                    ),
                                  ),

                                  //--
                                ),
                              ),
                            ],
                          ),
                        ),

                        //*** */
                      );
                    },
                  ),
                ),

                const Align(
                  alignment: Alignment.centerLeft,
                  child: Padding(
                    padding: EdgeInsets.only(left: 10.0),
                    child: Text('สูงสุด 8 ภาพ ขนาดไม่เกิน 2 MB'),
                  ),
                ),

                const SizedBox(
                  height: 20.0,
                ),

                //****

                Container(
                  padding: const EdgeInsets.only(
                      left: 5.0, top: 15.0, bottom: 10.0, right: 10.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'จังหวัด',
                              style: TextStyle(
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ],
                        ),
                      ),
                      InkWell(
                        child: const Text('น่าน'),
                        onTap: () {
                          print('f');
                          showCupertinoModalPopup<void>(
                            context: context,
                            builder: (BuildContext context) =>
                                CupertinoActionSheet(
                              title: const Text('Title'),
                              message: const Text('Message'),
                              actions: <CupertinoActionSheetAction>[
                                CupertinoActionSheetAction(
                                  child: const Text('ตกลง'),
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                      const Icon(
                        Icons.chevron_right,
                      ),
                    ],
                  ),
                ),
                // */
                Container(
                  padding: const EdgeInsets.all(5.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: const <Widget>[
                                Text('ชื่อสถานที่', textAlign: TextAlign.start),
                                Text(
                                  '*',
                                  textAlign: TextAlign.start,
                                  style: TextStyle(
                                    fontSize: 20.0,
                                    color: Colors.red,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(
                        width: 200.0,
                        child: TextField(
                          // maxLength: 100,
                          decoration: InputDecoration.collapsed(
                            hintText: '',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                // ***
                Container(
                  padding: const EdgeInsets.all(5.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'รายละเอียด',
                              style: TextStyle(
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ],
                        ),
                      ),
                      InkWell(
                        child: const Text('ตั้งค่า'),
                        onTap: () {
                          print('f');
                          showCupertinoModalPopup<void>(
                            context: context,
                            builder: (BuildContext context) =>
                                CupertinoActionSheet(
                              title: const Text('Title'),
                              message: const Text('Message'),
                              actions: <CupertinoActionSheetAction>[
                                CupertinoActionSheetAction(
                                  child: const Text('ตกลง'),
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                      const Icon(
                        Icons.chevron_right,
                      ),
                    ],
                  ),
                ),
                // ***
                Container(
                  padding:
                      const EdgeInsets.only(left: 5.0, top: 15.0, right: 10.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'ความนิยม',
                              style: TextStyle(
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ],
                        ),
                      ),
                      InkWell(
                        child: const Text('4.5'),
                        onTap: () {
                          print('f');
                          showCupertinoModalPopup<void>(
                            context: context,
                            builder: (BuildContext context) =>
                                CupertinoActionSheet(
                              title: const Text('Title'),
                              message: const Text('Message'),
                              actions: <CupertinoActionSheetAction>[
                                CupertinoActionSheetAction(
                                  child: const Text('ตกลง'),
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
                // ***
                Container(
                  padding: const EdgeInsets.only(
                      left: 5.0, top: 15.0, bottom: 10.0, right: 10.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'เวลาทำการ',
                              style: TextStyle(
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ],
                        ),
                      ),
                      InkWell(
                        child: const Text('08:00 - 20:00 น.'),
                        onTap: () {
                          print('f');
                          showCupertinoModalPopup<void>(
                            context: context,
                            builder: (BuildContext context) =>
                                CupertinoActionSheet(
                              title: const Text('Title'),
                              message: const Text('Message'),
                              actions: <CupertinoActionSheetAction>[
                                CupertinoActionSheetAction(
                                  child: const Text('ตกลง'),
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
                // ***
                Container(
                  padding:
                      const EdgeInsets.only(left: 5.0, top: 15.0, right: 10.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'ประเภทสถานที่',
                              style: TextStyle(
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ],
                        ),
                      ),
                      InkWell(
                        child: const Text('น่าน'),
                        onTap: () {
                          print('f');
                          showCupertinoModalPopup<void>(
                            context: context,
                            builder: (BuildContext context) =>
                                CupertinoActionSheet(
                              title: const Text('Title'),
                              message: const Text('Message'),
                              actions: <CupertinoActionSheetAction>[
                                CupertinoActionSheetAction(
                                  child: const Text('ตกลง'),
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
                // ***
                Container(
                  padding:
                      const EdgeInsets.only(left: 5.0, top: 15.0, right: 10.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'สถานที่ยอดนิยม',
                              style: TextStyle(
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Switch(
                        value: isSwitchedRecommended,
                        activeColor: Colors.green,
                        onChanged: (value) {
                          setState(() {
                            isSwitchedRecommended = value;
                          });
                        },
                      ),
                    ],
                  ),
                ),
                // ***
                Container(
                  padding: const EdgeInsets.only(left: 5.0, right: 10.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'แสดงผล',
                              style: TextStyle(
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Switch(
                        value: isSwitchedActive,
                        activeColor: Colors.green,
                        onChanged: (value) {
                          setState(() {
                            isSwitchedActive = value;
                          });
                        },
                      ),
                    ],
                  ),
                ),
                // **
                Container(
                  padding:
                      const EdgeInsets.only(left: 5.0, top: 15.0, right: 10.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'ที่อยู่',
                              style: TextStyle(
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ],
                        ),
                      ),
                      InkWell(
                        child: const Text('น่าน'),
                        onTap: () {
                          print('f');
                          showCupertinoModalPopup<void>(
                            context: context,
                            builder: (BuildContext context) =>
                                CupertinoActionSheet(
                              title: const Text('Title'),
                              message: const Text('Message'),
                              actions: <CupertinoActionSheetAction>[
                                CupertinoActionSheetAction(
                                  child: const Text('ตกลง'),
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                      const Icon(
                        Icons.chevron_right,
                      ),
                    ],
                  ),
                ),
                // ***
              ],
            ),
          );
        },
      ),

      //---

      // ----- Bottom Navigation Bar ----- //
      bottomNavigationBar: BottomNavigationBar(
        items: _menuBar,
        currentIndex: _selectedIndex,
        selectedItemColor: Theme.of(context).primaryColor,
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
      ),
      // ----- Bottom Navigation Bar ----- //
    );
  }

  onSearchTextChanged(String text) async {
    // _searchResult.clear();
    // if (text.isEmpty) {
    //   setState(() {});
    //   return;
    // }

    // _userDetails.forEach((userDetail) {
    //   if (userDetail.firstName.contains(text) ||
    //       userDetail.lastName.contains(text)) _searchResult.add(userDetail);
    // });

    debugPrint('onSearchTextChanged = $text');

    setState(
      () {},
    );
  }
}
