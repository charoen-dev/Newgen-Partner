import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:partners/modules/dashboard/bloc/place_bloc.dart';
import 'package:partners/modules/dashboard/models/place_model.dart';
import 'package:partners/modules/dashboard/screens/pages/homes/home_page.dart';
import 'package:partners/modules/dashboard/screens/pages/places/places_create.dart';
import 'package:partners/modules/dashboard/screens/pages/places/places_detail.dart';
import 'package:partners/modules/dashboard/screens/pages/settings/settings_home.dart';
import 'package:provider/provider.dart';

class PlacesHome extends StatefulWidget {
  const PlacesHome({Key? key}) : super(key: key);

  @override
  State<PlacesHome> createState() => _PlacesHomeState();
}

class _PlacesHomeState extends State<PlacesHome> {
  TextEditingController controller = TextEditingController();
  @override
  void initState() {
    super.initState();
    getPlaceData();
  }

  Future getPlaceData() async {
    await context.read<PlaceBloc>().getPlaceData();
  }

  Future onRefresh() async {
    Provider.of<PlaceBloc>(context).onRefresh(mounted);
  }

  // ***** Section 0 : Setup NavigationBar ***** //

  int _selectedIndex = 0;

  final List<Widget> _pageWidget = <Widget>[
    const HomePage(),
    const PlacesCreate(),
    const PlacesCreate(),
    const AnimatedListSample(),
  ];

  final List<BottomNavigationBarItem> _menuBar = <BottomNavigationBarItem>[
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.home,
      ),
      label: 'หน้าหลัก',
    ),
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.emoji_events,
      ),
      label: 'xxxxx',
    ),
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.notifications,
      ),
      label: 'xxxxx',
    ),
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.menu,
      ),
      label: 'xxxxx',
    ),
  ];

  void _onItemTapped(int index) {
    setState(
      () {
        _selectedIndex = index;
      },
    );
  }

  // ***** Section 0 : Setup NavigationBar ***** //
  final leftEditIcon = Container(
    color: Colors.green,
    alignment: Alignment.centerLeft,
    child: const Icon(Icons.edit),
  );
  final rightDeleteIcon = Container(
    color: Colors.red,
    alignment: Alignment.centerRight,
    child: const Icon(Icons.delete),
  );

  num countItems = 1;
  @override
  Widget build(BuildContext context) {
    final placeBlocPreview = context.watch<PlaceBloc>();

    return Scaffold(
      appBar: AppBar(
        title: Container(
          width: double.infinity,
          height: 50.0,
          decoration: BoxDecoration(
            //color: Colors.primaries,
            borderRadius: BorderRadius.circular(
              5.0,
            ),
          ),
          child: Center(
            child: TextField(
              controller: controller,
              decoration: InputDecoration(
                prefixIcon: const Icon(
                  Icons.search,
                ),
                suffixIcon: IconButton(
                  tooltip: 'ยกเลิกการค้นหา',
                  icon: const Icon(
                    Icons.clear,
                  ),
                  onPressed: () {
                    debugPrint(
                      'OnClick ClearTextSearch',
                    );
                    controller.clear();
                    onSearchTextChanged(
                      '',
                    );
                  },
                ),
                hintText: 'ค้นหาสถานที่/แหล่งท่องเที่ยว',
                border: InputBorder.none,
                focusedBorder: OutlineInputBorder(
                  borderSide: const BorderSide(
                    color: Colors.grey,
                    width: 1.0,
                  ),
                  borderRadius: BorderRadius.circular(
                    25.0,
                  ),
                ),
              ),
              onChanged: onSearchTextChanged,
            ),
          ),
        ),
      ),

      body: RefreshIndicator(
        onRefresh: () => onRefresh(),
        // child:
        // AnimationLimiter(
        child: placeBlocPreview.loading
            ? //const CircularProgressIndicator()
            Container(
                alignment: Alignment.center,
                child: const CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(
                    Colors.purple,
                  ),
                ),
              )
            : placeBlocPreview.palceData.isEmpty
                ? Container() //there is no data
                : ListView.builder(
                    padding: const EdgeInsets.only(
                        top: 30.0, left: 1.5, right: 1.5, bottom: 5.0),
                    itemCount: placeBlocPreview.palceData.length,
                    itemBuilder:
                        (BuildContext context, int countItemsPreviews) {
                      PlaceModel placeModelPreview =
                          placeBlocPreview.palceData[countItemsPreviews];
                      return Slidable(
                        key: Key(
                          placeModelPreview.placeId.toString(),
                        ),
                        
                        endActionPane: ActionPane(
                          motion: const ScrollMotion(),
                          children: [
                            SlidableAction(
                              onPressed: (ss) {
                                _moveItemsToTrash(placeModelPreview.placeId);
                              },
                              backgroundColor: Colors.red,
                              foregroundColor: Colors.white,
                              icon: Icons.delete,
                            ),
                          ],
                        ),
                        child: ListTile(
                          leading: SizedBox(
                            height: MediaQuery.of(context).size.height * 0.25,
                            width: MediaQuery.of(context).size.width * 0.25,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(10.0),
                              child: Stack(
                                children: [
                                  Image.network(
                                    placeModelPreview.placesModelHeroImageUrl
                                        .toString(),
                                    width: MediaQuery.of(context).size.width,
                                    height: MediaQuery.of(context).size.height,
                                    fit: BoxFit.fill,
                                  ),
                                  Positioned(
                                    top: 0.0,
                                    child: Container(
                                      alignment: Alignment.center,
                                      width: 35.0,
                                      color: Colors.grey.shade400,
                                      padding: const EdgeInsets.only(
                                        left: 5.0,
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                          left: 3.0,
                                          right: 3.0,
                                        ),
                                        child: Text(
                                          '${countItemsPreviews + 1}',
                                          style: const TextStyle(
                                            fontSize: 10.0,
                                          ),
                                        ),
                                      ),
                                      // Text(
                                      //   //placeModelPreview,
                                      //   //'99999',
                                      //   placeBlocPreview.palceData.length.toInt().toString(),

                                      //   style: TextStyle(
                                      //     fontSize: 10.0,
                                      //     color: Colors.white,
                                      //   ),
                                      // ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ),
                          title: Text(
                            // placeBlocPreview.palceData.toList().length.toString(),
                            placeModelPreview.placesModelName.toString(),
                          ),
                          subtitle: Text(
                            placeModelPreview.placesModelLocation.toString(),
                          ),
                          onTap: () {
                            debugPrint(
                              'OnClick ListItems DocID = ${placeModelPreview.placesModelDocumentId.toString()}',
                            );
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>
                                    //TodoScreen(),
                                    const PlacesDetail(),
                              ),
                            );
                          },
                          trailing: IconButton(
                            icon: const Icon(
                              Icons.more_vert,
                            ),
                            onPressed: () {
                              debugPrint(
                                'OnClick IconTrailing',
                              );
                            },
                          ),
                        ),
                      );
                    },
                  ),
        // ),
      ),

      // ----- Bottom Navigation Bar ----- //
      bottomNavigationBar: BottomNavigationBar(
        items: _menuBar,
        currentIndex: _selectedIndex,
        selectedItemColor: Theme.of(context).primaryColor,
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
      ),
      // ----- Bottom Navigation Bar ----- //

      // ===== Button Create ===== //
      floatingActionButton: FloatingActionButton.extended(
        tooltip: 'เพิ่มข้อมูลใหม่',
        splashColor: const Color(
          0xFFFF1818,
        ),
        icon: const Icon(
          Icons.add,
          size: 20.0,
          color: Color(
            0xFFEEEEEE,
          ),
        ),
        backgroundColor: const Color(
          0xFF1C658C,
        ),
        extendedTextStyle: const TextStyle(
          fontSize: 16,
        ),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const PlacesCreate(),
            ),
          );
        },
        label: const Text(
          'เพิ่ม',
          style: TextStyle(
            color: Color(
              0xFFEEEEEE,
            ),
            fontSize: 14.0,
            fontWeight: FontWeight.bold,
            decoration: TextDecoration.none,
          ),
        ),
      ),
      // ===== Button Create ===== //
    );
  }

  onSearchTextChanged(String text) async {
    // _searchResult.clear();
    // if (text.isEmpty) {
    //   setState(() {});
    //   return;
    // }

    // _userDetails.forEach((userDetail) {
    //   if (userDetail.firstName.contains(text) ||
    //       userDetail.lastName.contains(text)) _searchResult.add(userDetail);
    // });

    debugPrint('onSearchTextChanged = $text');

    setState(
      () {},
    );
  }

  // ========== Delete Item From Trash ========== //
  Future<void> deleteItemFromTrash() {
    return Fluttertoast.showToast(
      msg: 'เกิดข้อผิดพลาด',
      gravity: ToastGravity.BOTTOM,
      toastLength: Toast.LENGTH_SHORT,
      timeInSecForIosWeb: 1,
      backgroundColor: const Color(0xFFEEEEEE),
      textColor: const Color(0xFF23272B),
      fontSize: 16.0,
    );
  }

  void _moveItemsToTrash(ss) {
    showDialog(
      context: context,
      builder: (context) {
        print(ss);
        return CupertinoAlertDialog(
          title: const Text(
            'ลบข้อมูล',
            style: TextStyle(
              fontSize: 18.0,
            ),
          ),
          content: const Text(
            'ต้องการลบข้อมูลใช่หรือไม่ ?',
            style: TextStyle(
              fontSize: 14.0,
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text(
                'ยกเลิก',
                style: TextStyle(
                  color: Colors.blue,
                  fontSize: 18.0,
                ),
              ),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                print(context);
              },
              child: const Text(
                'ลบ',
                style: TextStyle(
                  color: Colors.red,
                  fontSize: 18.0,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}
