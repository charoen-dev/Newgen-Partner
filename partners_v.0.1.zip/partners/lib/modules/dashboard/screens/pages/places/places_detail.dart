import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:partners/modules/dashboard/bloc/place_bloc.dart';
import 'package:partners/modules/dashboard/models/place_model.dart';
import 'package:partners/modules/dashboard/screens/pages/homes/home_page.dart';
import 'package:partners/modules/dashboard/screens/pages/places/places_create.dart';
import 'package:partners/modules/dashboard/screens/pages/places/places_edit.dart';
import 'package:partners/modules/dashboard/screens/pages/settings/settings_home.dart';
import 'package:provider/provider.dart';

class PlacesDetail extends StatefulWidget {
  const PlacesDetail({Key? key}) : super(key: key);

  @override
  State<PlacesDetail> createState() => _PlacesDetailState();
}

class _PlacesDetailState extends State<PlacesDetail> {
  TextEditingController controller = TextEditingController();
  @override
  void initState() {
    super.initState();
    getPlaceData();
  }

  Future getPlaceData() async {
    await context.read<PlaceBloc>().getPlaceData();
  }

  Future onRefresh() async {
    Provider.of<PlaceBloc>(context).onRefresh(mounted);
  }

  // ***** Section 0 : Setup NavigationBar ***** //

  int _selectedIndex = 0;

  final List<Widget> _pageWidget = <Widget>[
    const HomePage(),
    const PlacesCreate(),
    const PlacesCreate(),
    const AnimatedListSample(),
  ];

  final List<BottomNavigationBarItem> _menuBar = <BottomNavigationBarItem>[
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.home,
      ),
      label: 'หน้าหลัก',
    ),
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.emoji_events,
      ),
      label: 'xxxxx',
    ),
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.notifications,
      ),
      label: 'xxxxx',
    ),
    const BottomNavigationBarItem(
      icon: Icon(
        Icons.menu,
      ),
      label: 'xxxxx',
    ),
  ];

  void _onItemTapped(int index) {
    setState(
      () {
        _selectedIndex = index;
      },
    );
  }

  // ***** Section 0 : Setup NavigationBar ***** //
  final leftEditIcon = Container(
    color: Colors.green,
    alignment: Alignment.centerLeft,
    child: const Icon(Icons.edit),
  );
  final rightDeleteIcon = Container(
    color: Colors.red,
    alignment: Alignment.centerRight,
    child: const Icon(Icons.delete),
  );

  @override
  Widget build(BuildContext context) {
    final placeBlocPreview = context.watch<PlaceBloc>();

    return Scaffold(
      appBar: AppBar(
        title: Container(
          width: double.infinity,
          height: 50.0,
          decoration: BoxDecoration(
            //color: Colors.primaries,
            borderRadius: BorderRadius.circular(
              5.0,
            ),
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(
              right: 10.0,
            ),
            child: IconButton(
              icon: const Icon(Icons.edit),
              tooltip: 'Increase volume by 10',
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const PlacesEdit(),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () => onRefresh(),
        child: placeBlocPreview.loading
            ? Container(
                alignment: Alignment.center,
                child: const CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(
                    Colors.purple,
                  ),
                ),
              )
            : placeBlocPreview.palceData.isEmpty
                ? Container() //there is no data
                : ListView.builder(
                    padding: const EdgeInsets.only(
                      top: 0.0,
                      bottom: 2.0,
                    ),
                    itemCount: 1,
                    itemBuilder: (BuildContext context, int index) {
                      PlaceModel placeModelPreview =
                          placeBlocPreview.palceData[index];
                      return Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Container(
                            alignment: Alignment.topCenter,
                            child: Image(
                              image: const NetworkImage(
                                'https://picsum.photos/250?image=1',
                              ),
                              width: MediaQuery.of(context).size.width,
                              fit: BoxFit.fitWidth,
                            ),
                          ),
                          Container(
                            alignment: Alignment.centerLeft,
                            child: Padding(
                              padding: const EdgeInsets.all(
                                15.0,
                              ),
                              child: Column(
                                children: <Widget>[
                                  Row(
                                    children: const [
                                      Expanded(
                                        child: Text(
                                          'ถนนคนเดินน่าน XX',
                                          style: TextStyle(
                                            fontSize: 25.0,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      RatingBarIndicator(
                                        rating: 2.5,
                                        itemBuilder: (context, index) => const Icon(
                                          Icons.star,
                                          color: Colors.amber,
                                        ),
                                        itemCount: 5,
                                        itemSize: 20.0,
                                        direction: Axis.horizontal,
                                      ),
                                      const Text(
                                        '(2.5)',
                                        style: TextStyle(
                                          fontSize: 15.0,
                                        ),
                                      ),
                                    ],
                                  ),

                                  Row(
                                    children: [
                                      Expanded(
                                        child: Padding(
                                          padding: const EdgeInsets.only(
                                            top: 2.0,
                                            bottom: 2.0,
                                          ),
                                          child: Row(
                                            children: const [
                                              Padding(
                                                padding: EdgeInsets.only(
                                                  right: 4.0,
                                                ),
                                                child: Icon(
                                                  Icons.location_on,
                                                  color: Colors.red,
                                                  size: 30.0,
                                                ),
                                              ),
                                              Expanded(
                                                child: Text(
                                                  'ตำบลพระพุทธบาท อำเภอเชียงกลาง',
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),

                                  Row(
                                    children: [
                                      const Padding(
                                        padding: EdgeInsets.only(
                                          top: 2.0,
                                          bottom: 2.0,
                                          left: 5.0,
                                        ),
                                        child: Padding(
                                          padding: EdgeInsets.only(right: 5.0),
                                          child: Icon(
                                            Icons.access_time,
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: const [
                                            Text(
                                              'เปิด 24 ชั่วโมง',
                                              style: TextStyle(
                                                fontWeight: FontWeight.normal,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      IconButton(
                                        icon: const Icon(
                                          Icons.content_copy,
                                        ),
                                        tooltip: 'Increase volume by 10',
                                        onPressed: () {
                                          print('object');
                                        },
                                      ),
                                      InkWell(
                                        child: const Padding(
                                          padding: EdgeInsets.only(
                                            right: 10.0,
                                          ),
                                          child: Text('น่าน'),
                                        ),
                                        onTap: () {
                                          print('f');
                                          showCupertinoModalPopup<void>(
                                            context: context,
                                            builder: (BuildContext context) =>
                                                CupertinoActionSheet(
                                              title: const Text('Title'),
                                              message: const Text('Message'),
                                              actions: <
                                                  CupertinoActionSheetAction>[
                                                CupertinoActionSheetAction(
                                                  child: const Text('ตกลง'),
                                                  onPressed: () {
                                                    Navigator.pop(context);
                                                  },
                                                ),
                                              ],
                                            ),
                                          );
                                        },
                                      ),
                                    ],
                                  ),

                                  Row(
                                    children: const [
                                      Expanded(
                                        child: Padding(
                                          padding: EdgeInsets.only(
                                              top: 10.0, bottom: 10.0),
                                          child: Text(
                                            'เก็บตกภาพบรรยากาศจากงาน Anime Japan 2022 ในบูธของ SPY x FAMILY มาในธีมน้องอาเนียเล่นซ่อนแอบกับคุณพ่อ น่ารักมากๆ🥰',
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),

                                  // ****
                                  GridView.count(
                                    shrinkWrap: true,
                                    crossAxisCount: 4,
                                    children: List.generate(
                                      7,
                                      (index) {
                                        return Center(
                                          child:
                                              //****** */
                                              Padding(
                                            padding: const EdgeInsets.all(
                                              5.0,
                                            ),
                                            child: Stack(
                                              children: [
                                                Container(
                                                  width: double.infinity,
                                                  margin: const EdgeInsets.all(
                                                    1.0,
                                                  ),
                                                  child: const ClipRRect(
                                                    borderRadius:
                                                        BorderRadius.all(
                                                      Radius.circular(
                                                        5.0,
                                                      ),
                                                    ),
                                                    child: Image(
                                                      image: NetworkImage(
                                                        'https://picsum.photos/250?image=1',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),

                                          //*** */
                                        );
                                      },
                                    ),
                                  ),
                                  // *****
                                ],
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
        // ),
      ),

      // ----- Bottom Navigation Bar ----- //
      bottomNavigationBar: BottomNavigationBar(
        items: _menuBar,
        currentIndex: _selectedIndex,
        selectedItemColor: Theme.of(context).primaryColor,
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
      ),
      // ----- Bottom Navigation Bar ----- //
    );
  }
}
