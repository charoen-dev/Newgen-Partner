class AuthLoginModel {
  String email;
  String password;

  AuthLoginModel({required this.email, required this.password});
}



