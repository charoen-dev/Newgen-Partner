import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_signin_button/flutter_signin_button.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:page_transition/page_transition.dart';
import 'package:partners/core/auth/model_auth.dart';
import 'package:partners/modules/dashboard/screens/pages/homes/home_page.dart';

// ********** Section 0 ********** //

// ===== Google SingIn ===== //
GoogleSignIn _googleSignIn = GoogleSignIn(
  scopes: <String>[
    'email',
    'https://www.googleapis.com/auth/contacts.readonly',
  ],
);
// ===== Google SingIn ===== //

// ********** Section 0 ********** //

// ********** Section 1 ********** //
class SplashLoginScreen extends StatelessWidget {
  const SplashLoginScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // ===== Splash Screen ===== //
    return AnimatedSplashScreen(
      splashIconSize: 300.0,
      duration: 1000,
      splash: Image.asset('assets/logo/icon/ico_place_512.png'),
      splashTransition: SplashTransition.scaleTransition,
      pageTransitionType: PageTransitionType.topToBottom,
      backgroundColor: const Color(0xFFEEEEEE),
      nextScreen: const LoginScreen(),
    );
    // ===== Splash Screen ===== //
  }
}
// ********** Section 1 ********** //

// ********** Section 2 ********** //
class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  // ===== Form Sign In ===== //
  final formKey = GlobalKey<FormState>();
  AuthLoginModel formLogIn = AuthLoginModel(
    email: '',
    password: '',
  );
  // ===== Form Sign In ===== //

  // =====  Google Sign In ===== //
  GoogleSignInAccount? _currentUser;
  final Future<FirebaseApp> firebase = Firebase.initializeApp();

  Future<void> _handleSignIn() async {
    try {
      await _googleSignIn.signIn();
      // print('object');
    } catch (error) {
      // print(error);
    }
  }

  // =====  Google Sign In ===== //
  @override
  // =====  Google Sign In ===== //
  void initState() {
    super.initState();
    _googleSignIn.onCurrentUserChanged.listen((GoogleSignInAccount? account) {
      setState(() {
        _currentUser = account;
      });
      if (_currentUser != null) {}
    });
    _googleSignIn.signInSilently();
  }

  // =====  Google Sign In ===== //
  // ===== Show/Hide Password ===== //
  bool showOrHidePassword = true;
  // ===== Show/Hide Password ===== //
  @override
  Widget build(BuildContext context) {
    // =====  Form Sign In ===== //
    return FutureBuilder(
      future: firebase,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          // ===== Check Firebase Connection ===== //
          return const CircularProgressIndicator();
          // ===== Check Firebase Connection ===== //
        }

        if (snapshot.connectionState == ConnectionState.done) {
          return Scaffold(
            body: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Form(
                key: formKey,
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const SizedBox(height: 70.0),

                      const CircularProgressIndicator(),

                      Row(
                        children: const <Widget>[
                          Expanded(
                            child: Divider(
                              height: 20.0,
                              thickness: 1.5,
                              indent: 15.0,
                              endIndent: 15.0,
                              color: Color(0xFF7f11e0),
                            ),
                          ),
                          Text(
                            'เข้าสู่ระบบ',
                            style: TextStyle(
                              fontSize: 18.0,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Expanded(
                            child: Divider(
                              height: 20.0,
                              thickness: 1.5,
                              indent: 15.0,
                              endIndent: 15.0,
                              color: Color(0xFF7f11e0),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 15.0),
                      // ===== Form LogIn ===== //
                      TextFormField(
                        autofocus: false,
                        maxLength: 50,
                        scrollPadding: const EdgeInsets.all(20.0),
                        decoration: const InputDecoration(
                          labelText: 'อีเมล',
                          hintText: 'example@example.com',
                          focusColor: Color(0xFF7f11e0),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Color(0xFF7f11e0), width: 2.0),
                          ),
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(10.0)),
                          ),
                          contentPadding: EdgeInsets.all(20.0),
                          suffixIcon: Icon(
                            Icons.email,
                          ),
                        ),
                        validator: MultiValidator(
                          [
                            RequiredValidator(errorText: 'กรุณาป้อนอีเมล'),
                            EmailValidator(errorText: 'อีเมลไม่ถูกต้อง')
                          ],
                        ),
                        keyboardType: TextInputType.emailAddress,
                        onSaved: (String? email) {
                          formLogIn.email = email!;
                        },
                      ),

                      const SizedBox(height: 10.0),

                      TextFormField(
                        autofocus: false,
                        maxLength: 50,
                        scrollPadding: const EdgeInsets.all(20.0),
                        decoration: const InputDecoration(
                          labelText: 'รหัสผ่าน',
                          hintText: '******',
                          focusColor: Color(0xFF7f11e0),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Color(0xFF7f11e0), width: 2.0),
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.all(
                              Radius.circular(10.0),
                            ),
                            borderSide: BorderSide(
                              color: Color(0xFF7f11e0),
                            ),
                          ),
                          contentPadding: EdgeInsets.all(20.0),
                          // *****
                          suffixIcon: Icon(
                            Icons.lock,
                          ),

                          // *******
                        ),
                        validator:
                            RequiredValidator(errorText: 'รหัสผ่านไม่ถูกต้อง'),
                        obscureText: true,
                        onSaved: (String? password) {
                          formLogIn.password = password!;
                        },
                      ),

                      // ===== Form LogIn ===== //
                      // ===== Forgot Password ===== //
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton(
                          onPressed: () {},
                          child: const Text(
                            'ลืมรหัสผ่าน ?',
                            style: TextStyle(
                              decoration: TextDecoration.underline,
                            ),
                          ),
                        ),
                      ),
                      // ===== Forgot Password ===== //

                      const SizedBox(height: 20.0),
                      // ===== Button Login ===== //
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          child: const Text('ลงชื่อเข้าใช้',
                              style: TextStyle(fontSize: 20.0)),
                          onPressed: () async {
                            if (formKey.currentState!.validate()) {
                              formKey.currentState?.save();
                              try {
                                await FirebaseAuth.instance
                                    .signInWithEmailAndPassword(
                                  email: formLogIn.email.toLowerCase(),
                                  password: formLogIn.password,
                                )
                                    .then(
                                  (value) {
                                    formKey.currentState?.reset();

                                    Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) {
                                          return const HomePage();
                                        },
                                      ),
                                    );
                                  },
                                );
                              } on FirebaseAuthException {
                                Fluttertoast.showToast(
                                    msg: 'อีเมลหรือรหัสผ่านไม่ถูกต้อง',
                                    gravity: ToastGravity.BOTTOM,
                                    toastLength: Toast.LENGTH_SHORT,
                                    timeInSecForIosWeb: 1,
                                    backgroundColor: const Color(0xFFEEEEEE),
                                    textColor: const Color(0xFF23272B),
                                    fontSize: 16.0);
                              }
                            }
                          },
                        ),
                      ),
                      // ===== Button Login ===== //
                      const SizedBox(
                        height: 10.0,
                      ),
                      // ===== Sign in - Google Accounts ===== //
                      Row(
                        children: const <Widget>[
                          Expanded(
                            child: Divider(
                              height: 20.0,
                              thickness: 1.5,
                              indent: 15.0,
                              endIndent: 15.0,
                              color: Color(0xFF7f11e0),
                            ),
                          ),
                          Text('เข้าสู่ระบบด้วย'),
                          Expanded(
                            child: Divider(
                              height: 20.0,
                              thickness: 1.5,
                              indent: 15.0,
                              endIndent: 15.0,
                              color: Color(0xFF7f11e0),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 20.0,
                      ),
                      Center(
                        widthFactor: double.infinity,
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            SignInButton(
                              Buttons.Google,
                              text: 'บัญชี Google',
                              padding: const EdgeInsets.all(1.0),
                              elevation: 2.0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              onPressed: () {
                                _handleSignIn();
                              },
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(
                        height: 10.0,
                      ),
                      // ===== Sign in - Google Accounts ===== //
                      // ===== SplashRegisterScreen ===== //
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text(
                            'ยังไม่มีบัญชีผู้ใช้ ?',
                            style: TextStyle(
                              fontSize: 14.0,
                              color: Color(0xFF7A8793),
                              fontWeight: FontWeight.normal,
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: TextButton(
                              onPressed: () {},
                              child: const Text(
                                'สมัคร',
                                style: TextStyle(
                                  fontSize: 16.0,
                                  color: Color(0xFFFF4891),
                                  fontWeight: FontWeight.bold,
                                  decoration: TextDecoration.underline,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      // ===== SplashRegisterScreen ===== //
                    ],
                  ),
                ),
              ),
            ),
          );
        }

        // ===== Error Connection ===== //
        return const CircularProgressIndicator();
        // ===== Error Connection ===== //
      },
    );
  }
  // ********** Section 2 ********** //
}
