import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flex_color_scheme/flex_color_scheme.dart';
import 'package:flutter/material.dart';
import 'package:partners/core/auth/login_auth.dart';
import 'package:partners/modules/dashboard/bloc/place_bloc.dart';
import 'package:partners/modules/dashboard/screens/pages/launcher.dart';
import 'package:provider/provider.dart';
import 'package:provider/single_child_widget.dart';

// ***************************************************************************************** //
// ********** Section 0 | Get Current User  ********* //
// ***************************************************************************************** //
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(
    MyApp(),
  );
}
// ***************************************************************************************** //
// ********** Section 0 | Get Current User  ********* //
// ***************************************************************************************** //

// ***************************************************************************************** //
// ********** Section 1 | Run App  ********* //
// ***************************************************************************************** //
class MyApp extends StatelessWidget {
  MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // ----- Setup MultiProvider ----- //
    return MultiProvider(
      providers: _multiProvider,
      child: const MyAppHome(),
    );
    // ----- Setup MultiProvider ----- //
  }

  // ----- Provider Get Data ----- //
  final List<SingleChildWidget> _multiProvider = [
    ChangeNotifierProvider<PlaceBloc>(
      create: (context) => PlaceBloc(),
    ),
    ChangeNotifierProvider<PlaceBloc>(
      create: (context) => PlaceBloc(),
    ),
    ChangeNotifierProvider<PlaceBloc>(
      create: (context) => PlaceBloc(),
    ),
    ChangeNotifierProvider<PlaceBloc>(
      create: (context) => PlaceBloc(),
    ),
    ChangeNotifierProvider<PlaceBloc>(
      create: (context) => PlaceBloc(),
    )
  ];
  // ----- Provider Get Data ----- //
}

class MyAppHome extends StatelessWidget {
  const MyAppHome({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.system,
      theme: FlexThemeData.light(
          scheme: FlexScheme.sanJuanBlue,
          appBarStyle: FlexAppBarStyle.background),
      darkTheme: FlexThemeData.dark(scheme: FlexScheme.sanJuanBlue),
      // ----- j ----- //
      home: FirebaseAuth.instance.currentUser == null
          ? const SplashLoginScreen()
          : const LauncherPages(),
      // ----- j ----- //
    );
  }
}

// ***************************************************************************************** //
// ********** Section 1 | Run App  ********* //
// ***************************************************************************************** //